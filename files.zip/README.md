# System Issues Tracker

A comprehensive, fully-functional web-based system issues tracker with 30 fields for complete issue management. Track issues across teams (Moja & Passage), monitor resolution times, and export data to CSV.

## Features

✅ **30 Comprehensive Fields**
- Report ID, Date Detected, Reported By, Team/Location
- System/Module, Title, Description
- Impact Level, Affected Users, Status, Frequency
- Expected/Actual Behavior, Steps to Reproduce
- Environment Details (Device, OS, App, Connection, Role)
- Business Impact, Workaround
- Internal/External Owners
- Resolution Tracking with Time-to-Resolve

✅ **Fully Functional**
- Add new issues with one click
- View complete issue details
- Search and filter by status/impact
- Export all data to CSV
- Delete issues
- Persistent local storage (data saves on your browser)

✅ **Professional Design**
- Clean, modern interface
- Brand color: #355574
- Responsive (works on desktop, tablet, mobile)
- Color-coded status and impact badges
- Dashboard with live statistics

✅ **No Backend Required**
- 100% client-side (no server needed)
- Works offline completely
- Data stored in browser localStorage

## Getting Started

### Option 1: Open Locally
1. Download `index.html`
2. Double-click to open in your browser
3. Start tracking issues immediately!

### Option 2: Deploy on GitHub Pages (Free)

#### Step 1: Create GitHub Account
- Go to https://github.com
- Sign up (free)

#### Step 2: Create Repository
1. Click the `+` icon → "New repository"
2. Name: `system-issues-tracker`
3. Add description: "System Issues Tracker - 30-field comprehensive tracking"
4. Choose "Public" (so it's accessible online)
5. Click "Create repository"

#### Step 3: Add Code
1. Click "Add file" → "Create new file"
2. Name it: `index.html`
3. Copy and paste the entire HTML code from the index.html file
4. Click "Commit new file"

#### Step 4: Enable GitHub Pages
1. Go to "Settings"
2. Click "Pages" (left menu)
3. Under "Source", select "main" branch
4. Click "Save"
5. You'll see your live URL: `https://yourusername.github.io/system-issues-tracker`

#### Step 5: Share Your Link
Your app is now live! Share the URL with your team.

### Option 3: Other Free Hosting

**Netlify:**
1. Go to https://app.netlify.com/drop
2. Drag and drop `index.html`
3. Get instant live link

**Vercel:**
1. Go to https://vercel.com
2. Upload HTML file
3. Get live URL instantly

## How to Use

1. **Add Issue**
   - Click "Add New Issue"
   - Fill in the 30 fields
   - Click "Add Issue"

2. **View Details**
   - Click the eye icon on any issue
   - See complete information
   - Delete if needed

3. **Search & Filter**
   - Search by ID, title, or owner
   - Filter by Status
   - Filter by Impact Level

4. **Export Data**
   - Click "Export CSV"
   - Download spreadsheet with all 30 fields
   - Open in Excel/Google Sheets

## Data Storage

- All data is stored in your browser's localStorage
- Data persists between sessions
- No server or cloud storage needed
- Your data is private and never uploaded

## Browser Support

- Chrome/Edge: ✅ Full support
- Firefox: ✅ Full support
- Safari: ✅ Full support
- Mobile browsers: ✅ Fully responsive

## All 30 Fields

1. Report ID
2. Date Detected
3. Reported By
4. Team/Location
5. System/Module
6. Title
7. Impact Level
8. Affected Users
9. Status
10. Frequency
11. Description
12. Expected Behavior
13. Actual Behavior
14. Steps to Reproduce
15. Screenshot Links
16. Device Type
17. OS/Version
18. App Version
19. Internet Connection
20. User Role
21. Business Impact
22. Workaround
23. Internal Owner (Moja)
24. External Owner (Passage)
25. Next Action
26. Target Resolution Date
27. Resolution
28. Root Cause
29. Date Resolved
30. MOJA Team Time to Resolve (hours)

## Status Options

- Open
- In Progress
- On Hold
- Resolved
- Closed

## Impact Levels

- Critical
- High
- Medium
- Low

## Technologies Used

- HTML5
- CSS3 (Responsive Design)
- Vanilla JavaScript
- Font Awesome Icons
- localStorage API

## License

Free to use and modify for your needs.

## Support

For questions or improvements, feel free to open an issue or contact your team.

---

**Ready to use?** Start tracking your system issues today! 🚀
