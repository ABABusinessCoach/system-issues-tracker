# System Issues Tracker - Quick Start Guide

## 🚀 Deploy in 5 Minutes

### Fastest Way: GitHub Pages

**Step 1:** Go to https://github.com and create account (free)

**Step 2:** Create new repository named `system-issues-tracker`

**Step 3:** Click "Add file" → "Create new file"

**Step 4:** Name it `index.html` and paste the HTML code

**Step 5:** Click "Commit new file"

**Step 6:** Go to Settings → Pages → Set source to "main" → Save

**Done!** Your app is live at: `https://yourusername.github.io/system-issues-tracker`

---

## 📋 How to Use the App

### Adding an Issue
1. Click **"Add New Issue"**
2. Fill in the form:
   - Report ID (auto-generated)
   - Date Detected (today's date auto-filled)
   - Reported By (required)
   - Title (required)
   - System/Module (required)
   - Impact Level: Critical, High, Medium, Low
   - Status: Open, In Progress, On Hold, Resolved, Closed
   - All other fields (environment, behavior, resolution, etc.)
3. Click **"Add Issue"**
4. Issue appears in the table immediately

### Viewing Issue Details
1. Find the issue in the table
2. Click the **eye icon** in the last column
3. See all 30 fields of information
4. Click **"Delete Issue"** to remove (if needed)
5. Click **"Close"** to go back

### Searching Issues
1. Type in the **search box** (ID, title, or owner name)
2. Results filter in real-time

### Filtering Issues
1. Use **Status dropdown** to filter by: Open, In Progress, On Hold, Resolved, Closed
2. Use **Impact dropdown** to filter by: Critical, High, Medium, Low
3. Combine filters together

### Exporting Data
1. Click **"Export CSV"**
2. File downloads to your computer
3. Open in Excel or Google Sheets
4. Contains all 30 fields for all issues

---

## 🎨 30 Fields Included

**Basic Info (5)**
- Report ID
- Date Detected
- Reported By
- Team/Location
- System/Module

**Issue Details (1)**
- Title
- Description

**Impact & Status (4)**
- Impact Level
- Affected Users
- Status
- Frequency

**Behavior (2)**
- Expected Behavior
- Actual Behavior

**Reproduction (2)**
- Steps to Reproduce
- Screenshot Links

**Environment (5)**
- Device Type
- OS/Version
- App Version
- Internet Connection
- User Role

**Business (2)**
- Business Impact
- Workaround

**Ownership (3)**
- Internal Owner (Moja)
- External Owner (Passage)
- Next Action

**Resolution (4)**
- Target Resolution Date
- Date Resolved
- Resolution Details
- Root Cause
- MOJA Team Time to Resolve (hours)

---

## 💾 Data Storage

✅ **No Account Needed**
- Data saves in browser (localStorage)
- No login required
- Works 100% offline

⚠️ **Important to Know**
- Each browser/computer has separate data
- Clearing browser cache will delete data
- Backup: Export to CSV regularly

---

## 🔗 Hosting Options (All Free)

| Platform | Setup Time | Features |
|----------|-----------|----------|
| **GitHub Pages** | 5 min | Free, reliable, shareable link |
| **Netlify** | 1 min | Drag & drop deployment |
| **Vercel** | 2 min | Fast, modern hosting |
| **Local** | 30 sec | Download and open HTML file |

---

## 📱 Devices Supported

✅ Desktop (Chrome, Firefox, Safari, Edge)
✅ Tablet (iPad, Android tablet)
✅ Mobile (iPhone, Android phone)
✅ Works offline

---

## 🎯 Status Values

- **Open** - New issue, not started
- **In Progress** - Being worked on
- **On Hold** - Blocked/waiting
- **Resolved** - Fixed, pending verification
- **Closed** - Complete and verified

---

## 🔴 Impact Levels

- **Critical** - System down, major business impact
- **High** - Significant functionality broken
- **Medium** - Feature partially broken
- **Low** - Minor issue, cosmetic

---

## ❓ FAQ

**Q: Can I use this with my team?**
A: Yes! Share the URL. Each person gets their own data. Export CSV to share findings.

**Q: Where is my data stored?**
A: In your browser (localStorage). Never uploaded to any server.

**Q: Can I add more fields?**
A: Yes! Edit index.html to add custom fields (requires HTML knowledge).

**Q: What if I lose my data?**
A: Always export CSV as backup. You can also use browser's export/import.

**Q: Does it work offline?**
A: Yes! 100% offline support. All features work without internet.

**Q: Can I add a database?**
A: Yes! We can integrate Firebase/Supabase for team data sharing (contact for paid version).

**Q: How do I update the app?**
A: Edit index.html in GitHub and commit. Updates instantly.

**Q: Is this secure?**
A: Yes! No sensitive data is transmitted. All local storage.

---

## 🛠️ Customization

### Change Brand Color
1. Open index.html in any text editor
2. Find: `#355574` (appears multiple times)
3. Replace with your color (e.g., `#1a5490`)
4. Save and re-upload to GitHub

### Change App Title
1. Find: `System Issues Tracker`
2. Replace with your preferred title
3. Save and re-upload

### Add Custom Fields
1. Find the form-section div
2. Add new input elements following the same pattern
3. Update JavaScript to handle new fields
4. Save and re-upload

---

## 📞 Support

- Works in all modern browsers
- Tested on Chrome, Firefox, Safari, Edge
- Mobile responsive
- No dependencies or installations needed

---

## 🎉 You're All Set!

Your System Issues Tracker is ready to use!

**Next Steps:**
1. ✅ Deploy to GitHub Pages (5 minutes)
2. ✅ Share link with your team
3. ✅ Start adding issues
4. ✅ Track and resolve!

**Questions?** Check GITHUB_SETUP.md for detailed deployment steps.

---

**Happy tracking!** 🚀
